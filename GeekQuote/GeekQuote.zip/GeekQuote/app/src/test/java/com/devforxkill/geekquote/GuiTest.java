package com.devforxkill.geekquote;

public class GuiTest {

    // sur la main activity : quand on ajoute une citation, elle doit apparaître dans la liste
}
