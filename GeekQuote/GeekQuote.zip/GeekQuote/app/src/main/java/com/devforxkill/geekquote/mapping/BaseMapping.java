package com.devforxkill.geekquote.mapping;

public interface BaseMapping {

    public static final String ID = "id";
}
